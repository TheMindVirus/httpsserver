﻿using UnityEngine;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System;

public class MulticastControl : MonoBehaviour
{
    private Thread thread;
    private Socket socket;
    private IPAddress multicast;
    private IPAddress localhost;
    private int port;
    private int mtu;
    private MulticastOption membership;
    private EndPoint local;
    private EndPoint global;
    private EndPoint client;
    private byte[] message;
    private byte[] buffer;
    private bool running;
    private float delta;
    private bool fault;
    
    void Configure(string in_multicast = "224.0.1.2", string in_localhost = "0.0.0.0", int in_port = 12345, int in_mtu = 1500)
    {
        Debug.Log("[INFO]: Configure");
        multicast = IPAddress.Parse(in_multicast);
        localhost = IPAddress.Parse(in_localhost);
        port = in_port;
        mtu = in_mtu;
        membership = new MulticastOption(multicast, localhost);
        local = (EndPoint)new IPEndPoint(localhost, port);
        global = (EndPoint)new IPEndPoint(multicast, port);
        client = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
        thread = new Thread(new ThreadStart(Receiver));
        buffer = new byte[mtu];
        running = true;
        thread.Start();
        fault = false;
    }

    void Reconnect()
    {
        Debug.Log("[INFO]: Reconnect");
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, 1);
        socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastInterface, 0);
        socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 32);
        socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastLoopback, 1);
        socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, membership);
        socket.Bind(local);
    }

    void Receiver()
    {
        Debug.Log("[INFO]: Receiver");
        while (running == true)
        {
            try
            {
                //buffer = new byte[mtu];
                if (socket != null) { socket.ReceiveFrom(buffer, buffer.Length, SocketFlags.None, ref client); }
                Debug.Log("[" + client.ToString() + "]: " + Encoding.UTF8.GetString(buffer));
            }
            catch(ThreadAbortException error)
            {
                Debug.Log("[INFO]: Abort");
                fault = true;
            }
            catch(Exception error)
            {
                Debug.Log("[WARN]: " + error.ToString());
                fault = true;
            }
        }
    }

    void Start()
    {
        Debug.Log("[INFO]: Start");
        Configure();
        Reconnect();
    }

    void Update()
    {
        delta += Time.deltaTime;
        if (delta >= 1.0f)
        {
            Debug.Log("[INFO]: Update");
            message = Encoding.UTF8.GetBytes("Message");
            try { if (socket != null) { socket.SendTo(message, 0, message.Length, SocketFlags.None, global); } }
            catch(Exception error) { Debug.Log("[WARN]: " + error.ToString()); fault = true; }
            if (fault == true) { Reconnect(); }
            delta = 0.0f;
        }
    }

    void Stop()
    {
        Debug.Log("[INFO]: Stop");
        running = false;
        if (thread != null)
        {
            thread.Abort();
            thread.Join();
            thread = null;
        }
        if (socket != null)
        {
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.DropMembership, membership);
            socket.Close();
            socket = null;
        }
    }

    void OnApplicationQuit() { Stop(); }
}
